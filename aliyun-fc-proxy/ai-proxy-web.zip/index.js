// 阿里云函数计算 FC 3.0 Web 函数（HTTP 函数）
// 原理：启动一个 HTTP 服务器监听 FC 指定端口，FC 把所有 HTTP 请求转发给它
// 优点：原生处理 HTTP 请求/响应，CORS 直接在代码里设置，没有 event 格式问题
// 部署：ZIP 根目录放 index.js，启动命令为 node index.js（Web 函数自动识别）

const http = require('http');
const https = require('https');
const { URL } = require('url');

const PORT = process.env.CAPORT || 9000;

function proxyToUpstream(upstream, apiKey, model, messages, callback) {
  const postData = JSON.stringify({ model: model, messages: messages });
  const targetUrl = new URL(upstream);

  const options = {
    method: 'POST',
    hostname: targetUrl.hostname,
    port: targetUrl.port || 443,
    path: targetUrl.pathname + targetUrl.search,
    headers: {
      'content-type': 'application/json',
      'authorization': 'Bearer ' + apiKey,
    },
  };

  const req = https.request(options, (res) => {
    const chunks = [];
    res.on('data', (c) => chunks.push(c));
    res.on('end', () => {
      callback(res.statusCode, Buffer.concat(chunks).toString('utf8'));
    });
  });

  req.on('error', (err) => {
    callback(502, JSON.stringify({ error: 'upstream fail: ' + err.message }));
  });

  req.setTimeout(60000, () => {
    req.destroy();
    callback(504, JSON.stringify({ error: 'timeout' }));
  });

  req.write(postData);
  req.end();
}

const server = http.createServer((req, res) => {
  // CORS 头
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'content-type, authorization');

  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    return res.end();
  }

  if (req.method === 'GET') {
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    return res.end('ai-proxy is running');
  }

  if (req.method !== 'POST') {
    res.statusCode = 405;
    return res.end('Method Not Allowed');
  }

  const chunks = [];
  req.on('data', (c) => chunks.push(c));
  req.on('end', () => {
    let payload;
    try {
      payload = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch (e) {
      res.statusCode = 400;
      res.setHeader('Content-Type', 'application/json');
      return res.end(JSON.stringify({ error: 'bad json' }));
    }

    const endpoint = payload.endpoint || process.env.UPSTREAM_ENDPOINT;
    const apiKey = payload.apiKey || process.env.UPSTREAM_API_KEY;
    const model = payload.model || process.env.UPSTREAM_MODEL || 'glm-5.1';
    const messages = payload.messages || [];

    if (!endpoint || !apiKey) {
      res.statusCode = 400;
      res.setHeader('Content-Type', 'application/json');
      return res.end(JSON.stringify({ error: 'missing endpoint/apikey' }));
    }

    const upstream = endpoint.endsWith('/chat/completions')
      ? endpoint
      : endpoint.replace(/\/+$/, '') + '/chat/completions';

    proxyToUpstream(upstream, apiKey, model, messages, (status, body) => {
      res.statusCode = status;
      res.setHeader('Content-Type', 'application/json');
      res.end(body);
    });
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('ai-proxy web function listening on port ' + PORT);
});
